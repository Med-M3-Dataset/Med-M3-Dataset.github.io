
import os
import json
import subprocess
import requests
import datetime
import shutil

# --- 全局配置 ---
# ==============================================================================
# 请根据您的实际部署情况修改此处的API端点和模式.
# 'mode' 可以是 'local' 或 'remote'.
# 'url' 是对应服务的API地址.
# ==============================================================================
CONFIG = {
    "asr": {
        "mode": os.environ.get('ASR_MODE', None),  
        "local_url": os.environ.get('ASR_URL', None),  
        "remote_url": os.environ.get('ASR_URL', None),  
        "key": os.environ.get('ASR_KEY', None)
    },
    "ocr": {
        "mode": os.environ.get('OCR_MODE', None),  
        "local_url": os.environ.get('OCR_URL', None),  
        "remote_url": os.environ.get('OCR_URL', None),  
        "key": os.environ.get('OCR_KEY', None)
    },
    "nlp": {
        "mode": os.environ.get('NLP_MODE', None),  
        "local_url": os.environ.get('NLP_URL', None),  
        "remote_url": os.environ.get('NLP_URL', None),  
        "key": os.environ.get('NLP_KEY', None)
    },
    "grounding_dino": {
        "mode": os.environ.get('DINO_MODE', None),  
        "local_url": os.environ.get('DINO_URL', None),  
        "remote_url": os.environ.get('DINO_URL', None),  
        "key": os.environ.get('DINO_KEY', None)
    },
    "encoder": {
        "mode": 'local',
        "local_url": os.environ.get('ENCODER_URL', None),  
    },
    "knowledge_graph_builder": {
        "mode": 'local',
        "local_url": os.environ.get('BUILDER_URL', None),
    },
    "mllm_solver": {
        "mode": os.environ.get('MLLM_MODE', None),  
        "local_url": os.environ.get('MLLM_URL', None),  
        "remote_url": os.environ.get('MLLM_URL', None),  
        "key": os.environ.get('MLLM_KEY', None)
    }
}

# --- 组件 1: 视频预处理 ---
def preprocess_video(video_path: str, output_dir: str) -> (str, str):
    """
    使用ffmpeg将视频拆分为音频和1fps的帧切片.
    :param video_path: 原始视频文件路径.
    :param output_dir: 帧和音频的输出目录.
    :return: (音频文件路径, 帧序列目录) 的元组.
    """
    print(f"[Component 1] Preprocessing video: {video_path}")
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    audio_output_path = os.path.join(output_dir, "audio.aac")
    frames_output_dir = os.path.join(output_dir, "frames")
    if not os.path.exists(frames_output_dir):
        os.makedirs(frames_output_dir)

    # 1. 提取音频
    audio_command = [
        "ffmpeg", "-i", video_path,
        "-y",  # 覆盖输出文件
        "-vn",  # 无视频
        "-acodec", "copy",
        audio_output_path
    ]
    subprocess.run(audio_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    print(f"  - Audio extracted to: {audio_output_path}")

    # 2. 提取1fps帧
    frames_command = [
        "ffmpeg", "-i", video_path,
        "-y",
        "-vf", "fps=1",
        os.path.join(frames_output_dir, "frame_%04d.png")
    ]
    subprocess.run(frames_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    print(f"  - Frames extracted to: {frames_output_dir}")

    return audio_output_path, frames_output_dir

# --- 组件 2: 语音识别 (ASR) ---
def run_asr(audio_path: str) -> dict:
    """
    调用ASR服务获取带时间戳的字幕.
    :param audio_path: 音频文件路径.
    :return: ASR服务返回的JSON对象.
    """
    print("[Component 2] Running Speech-to-Text (ASR)...")
    config = CONFIG["asr"]
    url = config["local_url"] if config["mode"] == "local" else config["remote_url"]
    
    with open(audio_path, "rb") as f:
        files = {"audio_file": (os.path.basename(audio_path), f)}
        response = requests.post(url, files=files)
        response.raise_for_status()
    print("  - ASR completed.")
    return response.json()

# --- 组件 3: 文字识别 (OCR) ---
def run_ocr(frames_dir: str) -> dict:
    """
    逐帧调用OCR服务获取带时间戳和位置的文本.
    :param frames_dir: 包含所有帧的目录.
    :return: 一个字典, key为帧文件名, value为OCR服务返回的JSON对象.
    """
    print("[Component 3] Running Optical Character Recognition (OCR)...")
    config = CONFIG["ocr"]
    url = config["local_url"] if config["mode"] == "local" else config["remote_url"]
    
    ocr_results = {}
    frame_files = sorted([f for f in os.listdir(frames_dir) if f.endswith(".png")])
    
    for frame_file in frame_files:
        frame_path = os.path.join(frames_dir, frame_file)
        with open(frame_path, "rb") as f:
            files = {"image_file": (frame_file, f)}
            response = requests.post(url, files=files)
            response.raise_for_status()
            ocr_results[frame_file] = response.json()
            
    print(f"  - OCR completed for {len(frame_files)} frames.")
    return ocr_results

# --- 组件 4: 自然语言处理 (NLP) ---
def run_nlp(asr_json: dict, ocr_json: dict, question: str) -> list:
    """
    调用NLP服务处理文本并提取关键词.
    :param asr_json: ASR返回的字幕JSON.
    :param ocr_json: OCR返回的文本JSON.
    :param question: 用户提出的问题.
    :return: 关键词或词组的列表.
    """
    print("[Component 4] Running Natural Language Processing (NLP)...")
    config = CONFIG["nlp"]
    url = config["local_url"] if config["mode"] == "local" else config["remote_url"]
    
    payload = {
        "asr_text": asr_json,
        "ocr_text": ocr_json,
        "question": question,
        "language_options": ["zh", "en"] # 示例: 要求同时处理中英文
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    keywords = response.json().get("keywords", [])
    print(f"  - NLP completed. Extracted keywords: {keywords}")
    return keywords

# --- 组件 5: 识别与编码 ---
def run_recognition_encoding(frames_dir: str, nlp_keywords: list) -> dict:
    """
    使用GroundingDino识别物体, 并用本地编码器进行编码.
    :param frames_dir: 包含所有帧的目录.
    :param nlp_keywords: NLP组件返回的关键词列表.
    :return: 包含物体位置、编码等信息的字典.
    """
    print("[Component 5] Running Recognition & Encoding...")
    dino_config = CONFIG["grounding_dino"]
    encoder_config = CONFIG["encoder"]
    
    dino_url = dino_config["local_url"] if dino_config["mode"] == "local" else dino_config["remote_url"]
    encoder_url = encoder_config["url"]
    
    recognition_results = {}
    prompt = ", ".join(nlp_keywords)
    frame_files = sorted([f for f in os.listdir(frames_dir) if f.endswith(".png")])

    for frame_file in frame_files:
        frame_path = os.path.join(frames_dir, frame_file)
        with open(frame_path, "rb") as f:
            # 1. 调用GroundingDino进行识别
            dino_payload = {"prompt": prompt}
            files = {"image_file": (frame_file, f)}
            dino_response = requests.post(dino_url, data=dino_payload, files=files)
            dino_response.raise_for_status()
            detections = dino_response.json().get("detections", [])
            
            # 2. 对检测到的物体区域进行编码
            # (假设Dino API返回了需要编码的区域信息)
            if detections:
                # 重置文件指针以重新读取
                f.seek(0)
                # 假设编码器API可以接受图像和检测框作为输入
                encoder_payload = {"detections": detections}
                files_for_encoder = {"image_file": (frame_file, f)}
                encoder_response = requests.post(encoder_url, json=encoder_payload, files=files_for_encoder)
                encoder_response.raise_for_status()
                
                recognition_results[frame_file] = encoder_response.json()

    print(f"  - Recognition & Encoding completed for {len(recognition_results)} frames.")
    return recognition_results

# --- 组件 6: 知识图谱构造 ---
def build_knowledge_graph(asr_json: dict, ocr_json: dict, recognition_data: dict, question: str) -> dict:
    """
    将所有信息输入到本地编码器以构造知识图谱.
    :param asr_json: ASR结果.
    :param ocr_json: OCR结果.
    :param recognition_data: 识别和编码结果.
    :param question: 原始问题.
    :return: 构造的知识图谱JSON对象.
    """
    print("[Component 6] Building Knowledge Graph...")
    url = CONFIG["knowledge_graph_builder"]["url"]
    
    payload = {
        "asr_input": asr_json,
        "ocr_input": ocr_json,
        "recognition_input": recognition_data,
        "question": question
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    print("  - Knowledge Graph constructed.")
    return response.json()

# --- 组件 7: 解答 ---
def get_answer(video_path: str, knowledge_graph: dict, question: str) -> (int, int):
    """
    将视频、知识图谱和问题输入MLLM以获取答案.
    :param video_path: 原始视频路径 (或其引用).
    :param knowledge_graph: 构造好的知识图谱.
    :param question: 原始问题.
    :return: (开始时间, 结束时间) 的元组.
    """
    print("[Component 7] Getting answer from MLLM...")
    url = CONFIG["mllm_solver"]["url"]
    
    # MLLM可能需要视频文件本身, 或只是一个路径/ID
    # 此处示例为传递路径和其它数据
    payload = {
        "video_reference": video_path,
        "knowledge_graph": knowledge_graph,
        "question": question
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    answer = response.json()
    start_time = answer.get("start_time_seconds")
    end_time = answer.get("end_time_seconds")
    print(f"  - Answer received: {start_time}s - {end_time}s.")
    return start_time, end_time


# --- 主函数 ---
def main():
    """
    主执行函数, 遍历问题, 处理视频并生成答案.
    """
    questions_file = "questions.json"
    videos_dir = "./videos"
    temp_base_dir = "./temp_processing"
    
    # 确保视频目录存在
    if not os.path.isdir(videos_dir):
        print(f"Error: Video directory not found at '{videos_dir}'")
        # 为方便演示, 创建一个空目录
        os.makedirs(videos_dir)
        print(f"Created directory '{videos_dir}'. Please add video files.")
        
    # 准备示例 questions.json
    if not os.path.exists(questions_file):
        print(f"Warning: '{questions_file}' not found. Creating a sample file.")
        sample_questions = [
            {"video_id": "sample_video_1.mp4", "question": "What is the person doing with the red ball?"},
            {"video_id": "sample_video_2.mp4", "question": "桌子上的书是什么颜色的?"}
        ]
        with open(questions_file, "w", encoding="utf-8") as f:
            json.dump(sample_questions, f, indent=4, ensure_ascii=False)
        print(f"Sample '{questions_file}' created. Please ensure 'sample_video_1.mp4' etc. exist in '{videos_dir}'.")
        return

    with open(questions_file, "r", encoding="utf-8") as f:
        questions_data = json.load(f)

    all_answers = []

    for item in questions_data:
        video_id = item["video_id"]
        question = item["question"]
        video_path = os.path.join(videos_dir, video_id)

        print(f"\n{'='*20} Processing video: {video_id} {'='*20}")
        print(f"Question: {question}")

        if not os.path.exists(video_path):
            print(f"  - SKIPPING: Video file not found at {video_path}")
            continue
            
        # 为当前视频创建一个独立的临时工作目录
        current_temp_dir = os.path.join(temp_base_dir, video_id.split('.')[0])
        if os.path.exists(current_temp_dir):
            shutil.rmtree(current_temp_dir) # 清理旧文件
        os.makedirs(current_temp_dir)

        try:
            # 1. 预处理
            audio_path, frames_dir = preprocess_video(video_path, current_temp_dir)
            
            # 2. 语音识别
            asr_json = run_asr(audio_path)
            
            # 3. OCR
            ocr_json = run_ocr(frames_dir)
            
            # 4. NLP
            nlp_keywords = run_nlp(asr_json, ocr_json, question)
            
            # 5. 识别与编码
            recognition_data = run_recognition_encoding(frames_dir, nlp_keywords)
            
            # 6. 知识图谱
            knowledge_graph = build_knowledge_graph(asr_json, ocr_json, recognition_data, question)
            
            # 7. 解答
            start_time, end_time = get_answer(video_path, knowledge_graph, question)
            
            # 收集答案
            all_answers.append({
                "video_id": video_id,
                "question": question,
                "answer": {
                    "start_time": start_time,
                    "end_time": end_time
                }
            })

        except requests.exceptions.RequestException as e:
            print(f"  - ERROR: API call failed. {e}")
            print("  - SKIPPING to next video.")
        except subprocess.CalledProcessError as e:
            print(f"  - ERROR: ffmpeg command failed. {e}")
            print(f"  - Stderr: {e.stderr.decode()}")
            print("  - SKIPPING to next video.")
        except Exception as e:
            print(f"  - ERROR: An unexpected error occurred. {e}")
            print("  - SKIPPING to next video.")
        finally:
            # 可以选择保留临时文件用于调试, 或删除它们
            # shutil.rmtree(current_temp_dir)
            print(f"  - Temporary files are in {current_temp_dir}")


    # 将所有答案写入一个带时间戳的JSON文件
    if all_answers:
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f"answers_{timestamp}.json"
        with open(output_filename, "w", encoding="utf-8") as f:
            json.dump(all_answers, f, indent=4, ensure_ascii=False)
        print(f"\nProcessing finished. All answers saved to '{output_filename}'.")
    else:
        print("\nProcessing finished, but no answers were generated.")


if __name__ == "__main__":
    main()
